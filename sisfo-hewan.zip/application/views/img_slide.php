<div class="container" style="margin-top: 77px;">
  <div class="row no-gutters" style="height: 400px;">
    <div class="col-12 col-lg-12">
      <section class="img_slide_header mb-4">
        <div class="swiper-container swiper_1">
            <div class="swiper-wrapper">
            <?php 
            $this->db->order_by('urutan');
            $qry = $this->db->get_where('t_gmb_slide', ['status' => 'Y']);
            foreach ($qry->result_object() as $row) {
             ?>
              <div class="swiper-slide" style="position: relative;">
                <div style="position: absolute; bottom: 0; background-color: rgba(0,0,0,0.6);" class="p-2 text-white" ><?php echo $row->caption; ?></div>
                <img src="<?php echo base_url('img/img_slide/'.$row->gambar); ?>" style="object-fit: cover; object-position: center; width: 100%; height: 400px;">
              </div>
            <?php } ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
          </div>
      </section>
    </div>
  </div>
</div>
	
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/swiper/js/swiper.min.js"></script>

  <script>
    var swiper = new Swiper('.swiper_1', {
      slidesPerView: 1,
      spaceBetween: 30,
      loop: true,
      /*autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },*/
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });

/*
    var swiper = new Swiper('.swiper_2', {
      slidesPerView: 4,
      spaceBetween: 30,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });*/

  </script>