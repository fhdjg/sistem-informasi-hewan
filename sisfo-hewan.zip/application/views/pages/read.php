<?php 
	$id_hewan = $this->uri->segment(2);
	$qry = $this->db->get_where('v_daftar_hewan', ['id' => $id_hewan]);
	$row = $qry->row();
 ?>
<div class="container" style="margin-top: 90px; min-height: 70vh;">
	<div class="row bg-white no-gutters">
		<?php $this->load->view('panel_kategori'); ?>
		<div class="col-12 col-lg-9 px-4">
			<div class="h3 my-3"><?php echo $row->nm_hewan; ?></div>
			<hr>
			<img src="<?php echo base_url('img/hewan/'.$row->gmb); ?>" class="w-100 mb-4">
			<?php echo $row->deskripsi; ?>
		</div>
	</div>
</div>