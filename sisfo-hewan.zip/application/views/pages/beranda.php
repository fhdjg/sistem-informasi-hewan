<style type="text/css">
	.tb_card tbody {
		/*display: flex;*/
	}
	.tb_card tbody tr{
		border: 1px solid #000;
		float: left;
	}
	.tb_card tbody tr td{
		display: block;
	}
</style>
<div class="container">
	<div class="row no-gutters">
		<?php $this->load->view('panel_kategori'); ?>
	    <div class="col-12 col-lg-9">
		  <div class="card flat border-bottom"> <!-- card -->
		    <div class="card-header bg-white text-uppercase flat ft-bold">
		    	<span class="gg-icon material-icons">format_list_bulleted</span> Daftar Hewan
		    	<?php echo @$this->uri->segment(2); ?>
		  	</div>
		  	<div class="card-body">
		  		<div class="row">
	  			<?php 
	  			if ($this->uri->segment(1) === 'hewan' AND !empty($this->uri->segment(2))) {
		  			$this->db->where('tempat_hidup', $this->uri->segment(2));
	  			}
	  			elseif ($this->uri->segment(1) === 'kategori' AND !empty($this->uri->segment(2))) {
		  			$this->db->where('nm_kategori', $this->uri->segment(2));
	  			}
	  			$this->db->order_by('nm_hewan');
	  			$qry = $this->db->get('v_daftar_hewan');
	  			foreach ($qry->result_object() as $row) {
	  			?>
		  			<div class="col-12 col-md-6 col-lg-4">
		              <div class="card mb-3 rounded-0 hover-2" style="height: 280px;">
		                <a href="<?php echo base_url('read/'.$row->id.'/'.url_dash($row->nm_hewan)); ?>">
		                  	<small class="badge badge-info absolute-top-left flat"><?php echo $row->nm_kategori; ?></small>
		                	<img class="card-img-top rounded-0" src="<?php echo base_url('img/hewan/'.$row->gmb); ?>" style="height: 200px; object-fit: cover; object-position: top;" alt="<?php echo $row->nm_hewan; ?>">
		                </a>
		                <div class="card-body text-center">
		                  <a class="text-capitalize" href="<?php echo base_url('read/'.$row->id.'/'.url_dash($row->nm_hewan)); ?>">
		                  	<?php echo $row->nm_hewan; ?>
		                  	</a>
		                </div>
		              </div>
		            </div>
		        <?php } ?>
		  		</div>
		  	</div>
		  </div> <!-- end card -->
	    </div>
	</div>
</div>