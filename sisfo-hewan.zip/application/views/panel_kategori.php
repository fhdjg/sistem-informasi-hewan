
	    <div class="col-12 col-lg-3">
	      <div class="list-group list-group-flush bg-primary h-100">
	      <?php 
	      $this->db->order_by('nm_kategori');
	      $qry = $this->db->get('t_kategori');
	      foreach ($qry->result_object() as $row) {
	       ?>
	        <a href="<?php echo base_url('kategori/'.url_dash($row->nm_kategori)); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center text-white shadow-sm text-uppercase" style="background-color: rgba(0,0,0,0.1);">
	          <?php echo $row->nm_kategori; ?> <span class="gg-icon mr-0 material-icons">keyboard_arrow_right</span>
	        </a>
	      <?php } ?>
	      </div>
	    </div>