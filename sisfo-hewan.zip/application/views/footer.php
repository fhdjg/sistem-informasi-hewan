	<footer class="container-fluid bg-dark text-white mt-5">
		<div class="row">
			<div class="col-12 py-4 text-center">
				&copy; Copyright <?php echo date('Y'); ?>
			</div>
		</div>
	</footer>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/popper.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/animate-css/css3-animate-it.js"></script>
	<script type="text/javascript">
		var url = location.pathname.split("/");
		var hostName = location.hostname;
		url = url[url.length -1 ];
		$('[href="http://'+hostName+ location.pathname+'"]').parent().parent().addClass('active');
		$('[href="http://'+hostName+ location.pathname+'"]').parent().addClass('active');
	</script>
</body>
</html>