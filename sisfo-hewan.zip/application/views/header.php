
<!DOCTYPE html>
<html>
<head>
	<title>Selamat Datang</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#000000">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>img/favicon.png">

	<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/material-icon/css/material-icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/swiper/css/swiper.min.css">
    <!-- <link rel="stylesheet" type="text/css" href="<?php base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.css"> -->
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/animate-css/animations.css"> -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/xakti-bs/xakti-bs.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/xakti-bs/main.css">

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/script.js"></script>
    <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/animate-css/animate.min.css"> -->
</head>
<body class="">