<?php 
  if (isset($_POST['masuk'])) {
    $post   = $this->input->post();
    $uname  = $post['Username'];
    $pass   = $post['Password'];
    $this->db->where('uname', $uname);
    $qry    = $this->db->get('t_admin');
    if ($qry->num_rows() === 1) {
      $row  = $qry->row();
      if (password_verify($pass, $row->pass)) {
        $_SESSION['admin_randi_id']    = $row->id;
        $_SESSION['admin_randi_nama']  = $row->nama;
        $_SESSION['admin_randi_uname'] = $row->uname;
        redirect('admin/beranda');
      }else{
        $msg  = "Password salah";
      }
    }else{
      $msg  = "Username tidak ada";
    }
  }
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login - Administrator</title>
    <link rel="shortcut icon" href="<?php echo base_url(); ?>img/favicon.png">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/material-icon/css/material-icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/xakti-bs/xakti-bs.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/xakti-bs/main.css">
  </head>
  <body>

    <div class="row no-gutters login-page-v2">
    <!-- <div class="row no-gutters login-page-v2" style="background-color: #2196f3;"> -->
      <div class="col-12 d-flex align-items-center align-content-stretch align-self-center">
        <div class="col-12 col-md-6 col-lg-3 mx-auto" style="overflow: hidden;">
          <div class="card flat border-bottom">
            <div class="card-header flat text-center" style="background-color: #fff;">
              <b>LOGIN</b>
            </div>
            <div class="card-body bg-white">
              <?php if (!empty($msg)): ?>
                <div class="alert alert-danger"><?php echo $msg; ?></div>
              <?php endif ?>
              <form method="POST">
                <div class="form-group">
                  <input type="text" class="form-control rounded-100" name="Username" placeholder="Username" autocomplete="off" required pattern="[a-zA-Z0-9 ]+" title="Hanya Huruf/angka yang dibolehkan">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control rounded-100" name="Password" placeholder="Password" autocomplete="off" required pattern="[a-zA-Z0-9 ]+" title="Hanya Huruf/angka yang dibolehkan">
                </div>
                <div class="form-group text-center">
                  <button class="btn btn-outline-dark rounded-100 w-100" name="masuk">Login</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
  </div>
  </body>
</html>
