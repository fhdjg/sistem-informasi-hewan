<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin</title>

    <link rel="shortcut icon" href="<?php base_url(); ?>../img/favicon.png">
    <script type="text/javascript" src="<?php base_url(); ?>../assets/plugins/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php base_url(); ?>../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php base_url(); ?>../assets/plugins/material-icon/css/material-icons.css">

    <link rel="stylesheet" type="text/css" href="<?php base_url(); ?>../assets/plugins/datatables/jquery.dataTables.min.css">
    
    <link rel="stylesheet" href="<?php base_url(); ?>../assets/xakti-bs/xakti-bs.css">
    <link rel="stylesheet" href="<?php base_url(); ?>../assets/xakti-bs/main.css?v=1">
  <script type="text/javascript" src="<?php base_url(); ?>../assets/js/script.js"></script>

  </head>
  <body>
    <div class="views layout-default theme-dark">
    <nav class="navbar navbar-expand-md fixed-top">
      <div class="navbar-brand brand-1" href="#">
        <a href="#" class="navbar-toggle hide-lg wave"><span class="gg-icon material-icons">menu</span></a>
        <span class="text-logo" style="font-weight: 400;">ADMIN PANEL</span>
      </div>
      <button class="btn btn-sm wave d-block d-sm-none btn-toggle-navbar-head"><span class="gg-icon material-icons">keyboard_arrow_down</span></button>
      <a class="sb-toggle wave" href="javascript:void(0);"><span class="gg-icon material-icons">menu</span></a>
      <div class="display-sm-none" style="color: #fff;"><?php echo strtoupper(''); ?></div>
      <!-- navbar head -->  
    </nav>

    