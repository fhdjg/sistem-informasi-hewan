
        </div> <!-- end content block -->
    </section> <!-- end main content -->
  </div>  <!-- end wrap -->
  
</div><!-- end wrap -->
</div>


  <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/popper.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.js"></script>
  <script type="text/javascript">
  	$('[href="'+location.href+'"]').parent().parent().parent().children('a').addClass('active');
  	$('[href="'+location.href+'"]').addClass('active');
  </script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/xakti-bs/xakti-bs.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/xakti-bs/main.js"></script>
  </body>
</html>
