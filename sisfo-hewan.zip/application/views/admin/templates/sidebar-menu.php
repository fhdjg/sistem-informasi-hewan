
    <!-- wrap -->
    <div class="wrap">
    <!-- sidebar -->
    <section class="sidebar shadow-1">

      <!-- sidebar menu -->
      <ul class="nav flex-column sidebar-nav">
        <!-- <div class="divider"></div> -->
        <li class="nav-item">
          <a class="nav-link hover-1" href="<?php echo base_url(); ?>admin/beranda"><span class="gg-icon material-icons">home</span>Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link hover-1" href="<?php echo base_url(); ?>admin/daftar-hewan"><span class="gg-icon material-icons">format_list_bulleted</span>Daftar Hewan</a>
        </li>
        <li class="nav-item nav-toggle">
          <a class="nav-link hover-1" href="javascript:void(0);"><span class="gg-icon material-icons">widgets</span>Master Data</a>
          <ul class="nav-dropdown bg-light">
            <!-- <li><a class="nav-link hover-1" href="<?php echo base_url(); ?>admin/daftar-provinsi"><span class="gg-icon material-icons font-18 ml-1">adjust</span>Daftar Provinsi</a></li> -->
            <li><a class="nav-link hover-1" href="<?php echo base_url(); ?>admin/daftar-kategori"><span class="gg-icon material-icons font-18 ml-1">adjust</span>Daftar Kategori</a></li>
          </ul>
        </li>
        <li class="nav-item nav-toggle">
          <a class="nav-link hover-1" href="javascript:void(0);"><span class="gg-icon material-icons">settings</span>Pengaturan</a>
          <ul class="nav-dropdown bg-light">
            <li><a class="nav-link hover-1" href="<?php echo base_url(); ?>admin/pengaturan-akun"><span class="gg-icon material-icons font-18 ml-1">adjust</span>Akun</a></li>
            <li><a class="nav-link hover-1" href="<?php echo base_url(); ?>admin/pengaturan-gambar-slide"><span class="gg-icon material-icons font-18 ml-1">adjust</span>Gambar Slide</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link hover-1" href="<?php echo base_url(); ?>link/logout_admin"><span class="gg-icon material-icons">power_settings_new</span>Logout</a>
        </li>
      </ul> <!-- end sidebar menu items -->
  </section> <!-- end sidebar -->


    <!-- main content -->
    <section class="main-content">

        <div class="content-block"> <!-- content-block -->