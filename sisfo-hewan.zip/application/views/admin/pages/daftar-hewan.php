<div class="row no-gutters"> <!-- row -->
<div class="col-12">
  <nav aria-label="breadcrumb" role="navigation">
    <ol class="breadcrumb bg-white flat border-bottom p-2 mb-2 font-14">
      <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>/admin"><span class="gg-icon mr-1 ml-1 material-icons font-20">home</span>Beranda</a></li>
      <li class="breadcrumb-item active" aria-current="page">Daftar Hewan</li>
    </ol>
  </nav>
</div>
<div class="col-12 col-lg-12"> <!-- col -->
  <div class="card flat border-bottom"> <!-- card -->
    <div class="card-header bg-white text-capitalize flat ft-bold justify-content-between d-flex">
      <a class="btn btn-outline-dark rounded-0 btn-sm" href="<?php echo base_url('admin/tulis-postingan'); ?>">TAMBAH DATA</a>
    <div class="row no-gutters">
      <div class="col">
        <input type="text" name="" class="form-control form-control-sm cs-form cs_search_dt" placeholder="Cari / Filter Data">
      </div>
    </div>
  </div>
    <div class="card-body pt-0">
      <table id="datatable" class="table table-hover w-100 cs-table" cellspacing="0">
        <thead>
          <tr class="bg-dark" style="color: #fff;">
            <th class="ft-weight-300" style="width: 25px;">No</th>
            <th class="ft-weight-300">Hewan</th>
            <th class="ft-weight-300">Tempat Hidup</th>
            <th class="ft-weight-300">Kategori</th>
            <th class="ft-weight-300">Gambar</th>
            <th class="ft-weight-300 text-center" style="min-width: 70px;">Aksi</th>
          </tr>
        </thead>
      </table>
    </div>
  </div> <!-- end card -->
</div> <!-- end col -->
</div> <!-- end row -->


<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/sweetalert.min.js"></script>
<script type="text/javascript">
  var srv = "<?php echo base_url(); ?>";
  $(document).ready(function() {
    var dt = $("#datatable").DataTable({
             "ajax": srv + "service/get_ss_hewan",
     "lengthChange": false,
            "bInfo": true,
        "searching": true,
      "deferRender": true,
       "processing": true,
       "serverSide": true,
       "pageLength": 10,
/*       "columnDefs": [{
          "searchable": false,
          "orderable": false,
          "targets": 5
      }],*/
   "fnInitComplete": function(){
      $('[data-toggle="tooltip"]').tooltip();
      $('[data-toggle="modal"]').tooltip();

   },
          "columns": [
          {
            render: function(data, type, row, meta){
              return meta.row  + 1 + '.';
            }
          },
          { "data": "nm_hewan"},
          { "data": "tempat_hidup"},
          { "data": "nm_kategori"},
          { 
            render: function(data, type, row){
              var img = (row.gmb === '' || row.gmb === null ? srv+'img/nopicture1.png' : srv + 'img/hewan/'+row.gmb);
              return '<a href="'+img+'" target="_blank"><img src="'+img+'" class="h-60px img-contain"></a>';
            }
          },
          {
            render: function(data, type, row){
              // var show ='<a href="#" class="btn btn-xs btn-'+(row.tampilkan === "Y" ? "dark":"secondary")+' rounded-0 m-0" ><i class="font-13 gg-icon material-icons">visibility</i> <span>'+row.dilihat+'</span></a>';
              var setting =
              '<div class="dropdown d-inline">'+
              '  <a class="btn btn-xs btn-dark rounded-0 m-0" href="#" role="button" id="dd_menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'+
              'Pilihan <i class="font-12 material-icons">arrow_drop_down</i>'+
              '  </a>'+
              '  <div class="dropdown-menu" aria-labelledby="dd_menu">'+
              '    <a class="dropdown-item" href="'+srv+'admin/tulis-postingan?id_post='+row.id+'"><i class="gg-icon material-icons">edit</i> Edit</a>'+
              '    <a href="#" class="dropdown-item btn_hapus" data-id="'+row.id+'" data-label="'+row.nm_hewan+'" data-gmb="'+row.gmb+'"><i class=" gg-icon material-icons">cancel</i> Hapus</a>'+
              '  </div>'+
              '</div>';
              return setting;
            }
          }
          ]
    }); /*end datatables*/

     dt.on('draw', function(){
      $('.btn_hapus').unbind();
      $('.btn_hapus').on('click', function(){
        var id = $(this).attr("data-id");
        var label = $(this).attr("data-label");
        var gmb = $(this).attr("data-gmb");

        swal({
          title: "Ingin Hapus Data ?",
          text: '"'+label+'"',
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $.post(srv + 'delete/daftar_hewan',{ id: id, gmb: gmb}, function(callback){
              dt.ajax.reload();
            });
          }
        });

      }); /*end btn_hapus*/

      $('.btn_visibility').unbind();
      $('.btn_visibility').on('click', function(){
        var id      = $(this).attr("data-id");
        var label   = $(this).attr("data-label");
        var status  = ($(this).attr("data-status") === 'Y' ? 'T' : 'Y');
        swal({
          title: (status === "Y" ? "Tampilkan" :"Sembunyikan") + " Postingan ?",
          text: '"'+label+'"',
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((confirm) => {
          if (confirm) {
            $.post(srv + 'execute_db/update_show_postingan/'+id+'/'+status, function(callback){
              dt.ajax.reload();
            });
          }
        });

      }); /*end btn_visibility*/



     }); /*end on draw*/

    $('.cs_search_dt').on('keyup', function () {
        $('#datatable').unbind();
        dt.search( this.value ).draw();
    });

    $('.mdl-view').on('show.bs.modal', function(e){
      var id = e.relatedTarget.attributes['data-id'].value;
      $('.tmp-postingan').html('');

      $.getJSON(srv + 'service/v_postingan/'+id , function(json){
        var row = json[0];
        var title = '<h5>'+row.judul+'</h5> <small class="text-muted">By : '+row.penerbit+' | '+tgl(row.terbit)+'</small>';
        $('.tmp-postingan').append(title);
        if (row.gmb !== '' && row.gmb !== null) {
          var img = '<img src="'+srv+'img/postingan/'+row.gmb+'" class="w-100">';
          $('.tmp-postingan').append(img);
        }
        $('.tmp-postingan').append('<hr>');
        $('.tmp-postingan').append(row.isi);
      });
    });

  });
</script>