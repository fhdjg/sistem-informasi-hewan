<?php 
  $id_admin = $this->session->userdata('admin_randi_id');
  $qry      = $this->db->get_where('t_admin', ['id' => $id_admin]);
  $row      = $qry->row();
  if (isset($_POST['btn_request'])) {
    $data['nama']  = repInjeksi($_POST['nama']);
    $data['uname'] = repInjeksi($_POST['uname']);
    if (!empty($data['pass'])) {
      $data['pass'] = $_POST['pass'];
    }
    $qry = $this->exec_db->update('t_admin', 'id', $id_admin, $data);
    if ($qry === 'sukses_update') {
      $_SESSION['admin_randi_nama']  = $_POST['nama'];
      $_SESSION['admin_randi_uname'] = $_POST['uname'];
      $msg = "Data Berhasil Diperbarui";
      // redirect('admin/pengaturan-akun');
    }else{
      $msg = "Data Gagal Diperbarui";
    }
  }
 ?>
<div class="col-12 col-lg-5 offset-lg-3"> <!-- col -->
  <div class="card flat border-bottom bg-white mt-4"> <!-- card -->
    <div class="card-header bg-white font-20">
      Pengaturan Akun
    </div>
    <div class="card-body">
      <?php if (!empty($msg)): ?>
        <div class="alert alert-success"><?php echo @$msg; ?></div>
      <?php endif ?>
      <form method="POST">
        <div class="form-group">
          <label>Nama Lengkap</label>
          <input type="text" name="nama" class="form-control cs-form form-control-sm" required value="<?php echo $this->session->userdata('admin_randi_nama'); ?>">
        </div>
        <div class="form-group">
          <label>Username</label>
          <input type="text" name="uname" class="form-control cs-form form-control-sm" required value="<?php echo $this->session->userdata('admin_randi_uname'); ?>">
        </div>
        <div class="form-group">
          <label>Password *</label>
          <input type="text" name="pass" class="form-control cs-form form-control-sm" autocomplete="off" pattern="[a-zA-Z0-9 ]+" title="Hanya Huruf/angka yang dibolehkan">
        </div>
        <div class="form-group text-right">
          <button class="btn btn-sm btn-outline-danger rounded-0" type="submit" name="btn_request">Perbarui Data</button>
        </div>
      </form>
    </div>
  </div> <!-- end card -->
</div> <!-- end col -->
