<style type="text/css">
  .cs-table1 tr td:first-child{
    width: 150px;
  }
</style>
<div class="row no-gutters"> <!-- row -->
<div class="col-12">
  <nav aria-label="breadcrumb" role="navigation">
    <ol class="breadcrumb bg-white flat border-bottom p-2 mb-2 font-14">
      <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>/admin"><span class="gg-icon mr-1 ml-1 material-icons font-20">home</span>Beranda</a></li>
      <li class="breadcrumb-item active" aria-current="page">Gambar Slide</li>
    </ol>
  </nav>
</div>
<div class="col-12 col-lg-12"> <!-- col -->
  <div class="card flat border-bottom"> <!-- card -->
    <div class="card-header bg-white text-capitalize flat ft-bold justify-content-between d-flex">
    <!-- gmb_slide -->
    <a href="javascript:" data-toggle="modal" data-target=".mdl-tmb_gmb_slide" class="btn btn-outline-dark btn-sm rounded-0">+ TAMBAH DATA</a>
    <div class="row no-gutters">
      <div class="col">
        <input type="text" name="" class="form-control form-control-sm cs-form cs_search_dt" placeholder="Cari / Filter Data">
      </div>
    </div>
  </div>
    <div class="card-body pt-0">
      <table id="datatable" class="table table-striped table-hover w-100 cs-table" cellspacing="0">
        <thead>
          <tr class="bg-dark" style="color: #fff;">
            <th class="ft-weight-300" style="width: 25px;">No</th>
            <th class="ft-weight-300">Gambar</th>
            <th class="ft-weight-300">Caption</th>
            <th class="ft-weight-300">Urutan</th>
            <th class="ft-weight-300">Tampilkan</th>
            <th class="ft-weight-300" style="width: 80px;">Aksi</th>
          </tr>
        </thead>
      </table>
    </div>
  </div> <!-- end card -->
</div> <!-- end col -->

<div class="modal mdl-tmb_gmb_slide fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form method="POST" id="form_id" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title ft-weight-300 lbl-buat_gmb_slide">Input Gambar Slide</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="gmb_slide">
              Upload Gambar : 
              <img src="<?php echo base_url() ?>img/nopicture.png" id="tmp_gmb_slide" style="height: 100px; border: 1px solid #ddd; width: 100%; object-fit: contain; cursor: pointer;">
            </label>
            <input type="file" class="d-none" id="gmb_slide" name="gmb_slide" accept="image/*" >
          </div>
          <div class="form-group">
            <label>Caption</label>
            <input type="text" name="txt_caption" class="form-control form-control-sm cs-form" required>
          </div>
          <div class="form-group">
            <label>Urutan</label>
            <input type="text" name="txt_urutan" class="form-control form-control-sm cs-form" required>
          </div>
          <div class="form-group">
            <label>Tampilkan</label>
            <select class="form-control form-control-sm cs-form" name="txt_status" required>
              <option value="">Pilih</option>
              <option value="Y">YA</option>
              <option value="T">TIDAK</option>
            </select>
          </div>
        </div> <!-- end modal-body -->
        <div class="card-footer text-right">
          <a href="javascript:" class="btn btn-secondary flat" data-dismiss="modal">Tutup</a>
          <button class="btn btn-primary flat" id="btn_submit" type="submit" name="btn_submit">Simpan Data</button>
        </div>
      </form>
    </div> <!-- end modal-content -->
  </div>
</div>
</div> <!-- end row -->

<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/sweetalert.min.js"></script>
<script type="text/javascript">
  var srv = "<?php echo base_url(); ?>";

showImg('#gmb_slide', '#tmp_gmb_slide');

function clear_inputan(){
  $('#tmp_gmb_slide').attr('src', srv + 'img/nopicture.png');
  $('#gmb_slide').val('');
  $('[name="txt_caption"]').val('');
  $('[name="txt_urutan"]').val('');
  $('[name="txt_status"]').val('');
}

  $(document).ready(function() {
    var dt = $("#datatable").DataTable({
             "ajax": srv + "service/get_ss_gmb_slide",
     "lengthChange": false,
            "bInfo": true,
        "searching": true,
      "deferRender": true,
       "processing": true,
       "serverSide": true,
       "pageLength": 10,
          // "scrollX": true,
   "fnInitComplete": function(){
      $('[data-toggle="tooltip"]').tooltip();
      $('[data-toggle="modal"]').tooltip();
   },
          "columns": [
          {
            render: function(data, type, row, meta){
              return meta.row  + 1 + '.';
            }
          },
          {
            render: function(data, type, row){
              var gmb = '<a href="'+ srv +'img/img_slide/'+row.gambar+'" target="_blank"><img src="'+ srv +'img/img_slide/'+row.gambar+'" class="h-50px"></a>';
              return gmb;
            }
          },
          { "data": "caption"},
          { "data": "urutan"},
          { "data": "status"},
          {
            render: function(data, type, row){
              var show ='<a href="javascript:" class="btn btn-xs btn-'+(row.status === "Y" ? "dark":"secondary")+' flat m-0 btn_visibility" data-id="'+row.id+'" data-label="'+row.caption+'" data-status="'+row.status+'"><i class="font-13 gg-icon material-icons">visibility'+(row.tampilkan === "Y" ? "_off" :"")+'</i></a>';
              var hapus ='<a href="javascript:" class="btn btn-xs flat btn-danger btn_hapus m-0" data-id="'+row.id+'" data-gmb="'+row.gambar+'" data-label="'+row.caption+'" data-toggle="tooltip" data-placement="top" title="Hapus"><i class="font-12 material-icons">cancel</i></a>';
              var edit = '<a href="javascript:" data-id="'+row.id+'" class="btn btn-xs flat btn-primary m-0" data-target=".mdl-tmb_gmb_slide" data-toggle="modal" data-placement="top" title="Edit"><i class="font-12 material-icons">edit</i></a>';
              return show +' '+ hapus +' '+ edit;
            }
          }
          ]
    });

     dt.on('draw', function(){
      $('.btn_hapus').unbind();

      $('.btn_hapus').on('click', function(){
        var id = $(this).attr("data-id");
        var gmb = $(this).attr("data-gmb");
        var label = $(this).attr("data-label");
        var r = confirm("Hapus "+ label + " ?");
        if (r === true) {
          $.post(srv + 'delete/del_gmb_slide', { id : id, gmb: gmb }, function(callback){
            console.log(callback);
            dt.ajax.reload();
          });
        }
      });

      $('.btn_visibility').unbind();
      $('.btn_visibility').on('click', function(){
        var id      = $(this).attr("data-id");
        var label   = $(this).attr("data-label");
        var status  = ($(this).attr("data-status") === 'Y' ? 'T' : 'Y');
        swal({
          title: (status === "Y" ? "Tampilkan" :"Sembunyikan") + " Postingan ?",
          text: '"'+label+'"',
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((confirm) => {
          if (confirm) {
            $.post(srv + 'request/update_show_gmb_slide/'+id+'/'+status, function(callback){
              dt.ajax.reload();
            });
          }
        });

      }); /*end btn_visibility*/

     }); /*end dt.draw*/

    $('.cs_search_dt').on('keyup', function () {
      $('#datatable').unbind();
        dt.search( this.value ).draw();
    });

    $('.mdl-tmb_gmb_slide').on('hidden.bs.modal', function(e){
      $('.lbl-buat_gmb_slide').html('Input Gambar Slide');
      $('[name="gmb_slide"]').val('');
    });

    $('.mdl-tmb_gmb_slide').on('show.bs.modal', function(e){
      var id = e.relatedTarget.attributes['data-id'];
      if (!id) {
        $('#btn_submit').html('Simpan Data');
      }else{
        $('.lbl-buat_gmb_slide').html('Perbarui Gambar Slide');
        $.getJSON(srv + 'service/get_gmb_slide/' + id.value, function(json){
          var row = json[0];
          $('#tmp_gmb_slide').attr('src', srv + 'img/img_slide/'+row.gambar);
          // $('#gmb_slide').val('');
          $('[name="txt_caption"]').val(row.caption);
          $('[name="txt_urutan"]').val(row.urutan);
          $('[name="txt_status"]').val(row.status);
        });
        $('#btn_submit').val(id.value);
        $('#btn_submit').html('Perbarui Data');
      }

      $('#form_id').submit(function(e){
        e.preventDefault();
        e.stopImmediatePropagation;
        var datas = new FormData(this);
        var button = $('#btn_submit').html();

        if (button === 'Simpan Data') {
          // dataUrl = srv + 'request/up';
          dataUrl = srv + 'request/cu_gmb_slide?action=insert';
        }else
        if(button === 'Perbarui Data'){
          var id = $('#btn_submit').val();
          dataUrl = srv + 'request/cu_gmb_slide?action=update&id='+id;
        }
        $.ajax({
          type: 'POST',
          url: dataUrl,
          data: datas,
          processData:false,
          contentType: false,
          cache:false,
          async:false,
          success: function(callback){
            console.log(callback);
            $('.mdl-tmb_gmb_slide').modal('hide');
            dt.ajax.reload();
            clear_inputan();
            $('#form_id').unbind('submit');
          },
          error: function(err){
            console.log('error coy'+ err);
            $('#form_id').unbind('submit');
          }
        });
      }); /*end submit gmb_slide*/

    }); /*end show.bs.modal*/


  }); /*end document.ready*/


</script>