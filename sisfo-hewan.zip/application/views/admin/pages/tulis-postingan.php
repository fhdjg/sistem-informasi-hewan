<?php 
  if (empty($_GET['id_post'])) {
    $title    = "Buat Postingan";
    $button   = "Simpan Data";
  }else{
    $title    = "Edit Postingan";
    $button   = "Perbarui Data";
    $this->db->where('id', $_GET['id_post']);
    $qry  = $this->db->get("v_daftar_hewan");
    $post = $qry->row();
  }
 ?>

<!-- <link rel="stylesheet" type="text/css" href="<?php base_url(); ?>../assets/plugins/select2/select2.min.css"> -->
 <style>
.ck-editor__editable {
    min-height: 66vh;
    max-height: 66vh;
    border: 1px solid #ddd !important;
}
.select2-container--default .select2-selection--multiple{
	border-radius: unset;
	border: 1px solid #ddd;
}
</style>
<form method="POST" id="form_id" enctype="multipart/form-data">
<div class="row no-gutters"> <!-- row -->

<div class="col-12">
  <nav aria-label="breadcrumb-item" role="navigation">
    <ol class="breadcrumb bg-white flat border-bottom p-2 mb-2 font-14">
      <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>/admin"><span class="gg-icon mr-1 ml-1 material-icons font-20">home</span>Beranda</a></li>
      <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>/admin/daftar-hewan">Daftar Hewan</a></li>
      <li class="breadcrumb-item active" aria-current="page"><?php echo $title; ?></li>
    </ol>
  </nav>
</div>
<div class="col-12 col-lg-12 py-2 bg-white"> 
  <div class="row">
    <div class="col-12 col-lg-4">
      <div class="form-group">
          Gambar Hewan:
         <br>
        <label for="gmb_header">
          <img class="border p-2" src="<?php echo base_url() ?>img/<?php echo (empty(@$post->gmb)) ? 'nopicture.png' :'hewan/'.$post->gmb; ?>" id="tmp_gmb_header" style="height: 150px; width: 150px; object-fit: contain; cursor: pointer; position: relative;">
        </label>
        <input class="d-none" type="file" id="gmb_header" accept="image/*" name="gmb" />
      </div>
      <div class="form-group">
        <label>Nama Hewan :</label>
        <input type="text" name="nm_hewan" class="form-control form-control-sm cs-form" required value="<?php echo @$post->nm_hewan; ?>">
      </div>
      <div class="form-group">
        <label>Tempat Hidup :</label>
        <select class="form-control form-control-sm cs-form" name="tempat_hidup" required>
          <option value="">Pilih..</option>
        <?php 
          $this->db->order_by('nm_th');
          $qry = $this->db->get('t_tempat_hidup');
          foreach ($qry->result_object() as $th){ ?>
          <option <?php echo (@$post->id_tempat_hidup === $th->id) ? 'selected' : '' ; ?> value="<?php echo $th->id; ?>"><?php echo ucfirst($th->nm_th); ?></option>
      <?php  }
         ?>
        </select>
      </div>
      <div class="form-group">
        <label>Kategori :</label>
        <select class="form-control form-control-sm cs-form" name="id_kategori" required>
          <option value="">Pilih..</option>
        <?php 
          $this->db->order_by('nm_kategori');
          $qry = $this->db->get('t_kategori');
          foreach ($qry->result_object() as $kat){ ?>
          <option <?php echo (@$post->id_kategori === $kat->id) ? 'selected' : '' ; ?>  value="<?php echo $kat->id; ?>"><?php echo $kat->nm_kategori; ?></option>
      <?php  }
         ?>
        </select>
      </div>
      <div class="form-group text-right">
        <button id="btn_tulis_postingan" value="<?php echo $button; ?>" type="submit" class="btn btn-primary flat"><?php echo $button; ?></button>
      </div>
    </div>
    <div class="col-12 col-lg-8">
      <div class="form-group">
        <textarea id="isi_postingan"><?php echo @$post->deskripsi; ?></textarea>
      </div>
    </div>
  </div> <!-- end row -->
</div>

</div> <!-- end row -->

</form>
	<!-- <script type="text/javascript" src="<?php base_url(); ?>../assets/plugins/select2/select2.min.js"></script> -->
	<!-- <script type="text/javascript" src="<?php base_url(); ?>../assets/plugins/sweetAlert2/sweetalert2.js"></script> -->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/ckeditor/ckeditor.js"></script>
	<script>
  var srv = "<?php echo base_url(); ?>";
  var id_post = "<?php echo @$_GET['id_post']; ?>";
/*
  $(document).ready(function() {
      $('.selectTag').select2();
  });
*/


    CKEDITOR.config.entities = false;
    CKEDITOR.config.basicEntities = false;
    CKEDITOR.config.entities_greek = false;
    CKEDITOR.config.entities_latin = false;
    CKEDITOR.config.entities_additional = '';
    CKEDITOR.config.htmlEncodeOutput = false;
    var editor = CKEDITOR.replace('isi_postingan');
    CKEDITOR.config.height="60vh";

	showImg('#gmb_header', '#tmp_gmb_header');

  $('.btn_del_gmb').on('click', function(){
    var gmb_old = $('#tmp_gmb_header').attr('src');
    gmb         = gmb_old.replace(srv +'img/postingan/', '');
    $.post(srv + 'request/del_gmb_postingan/' + id_post + '/' +gmb, function(){
      $('#tmp_gmb_header').attr('src', srv + 'img/nopicture.png');
      $('#gmb_header').val('');
    });
  });

  $('#form_id').submit(function(e){
    e.preventDefault();
    e.stopImmediatePropagation;
    var button = $('#btn_tulis_postingan').val();
    var datas = new FormData(this);
    datas.append("deskripsi", editor.getData());

    if (button === 'Simpan Data') {
     var dataUrl = srv + 'request/cu_postingan/insert';
    }else
    if(button === 'Perbarui Data'){
      var id = '<?php echo @$_GET["id_post"]; ?>';
      var dataUrl = srv + 'request/cu_postingan/update?id='+id;
    }
    $.ajax({
      type: 'POST',
      url: dataUrl,
      data: datas,
      processData:false,
      contentType: false,
      cache:false,
      async:false,
      success: function(callback){
      	if (callback === 'sukses_insert' || callback === 'sukses_update') {
	      	window.location.href = srv + 'admin/daftar-hewan';
      	}
      },
      error: function(err){
        console.log('error '+ err);
      }
    });
  }); /*end submit postingan*/
</script>