
<?php 
	$qry = $this->db->query("SELECT
			(SELECT COUNT(*) FROM t_hewan) AS total_hewan,
			(SELECT COUNT(*) FROM t_hewan WHERE id_tempat_hidup = 1) AS hewan_darat,
			(SELECT COUNT(*) FROM t_hewan WHERE id_tempat_hidup = 2) AS hewan_air,
			(SELECT COUNT(*) FROM t_hewan WHERE id_tempat_hidup = 3) AS hewan_udara");
	$row = $qry->row();
 ?>
<div class="row"> <!-- row -->
  <div class="col-sm-12 col-md-6 col-lg-3 p-2">
    <div class="info-box-3 bg-white border-bottom">
      <div class="info-box-icon bg-maroon">
        <i class="gg-icon material-icons">bubble_chart</i>
      </div>
      <div class="info-box-body text-muted">
        <div class="info-box-title">Hewan Air</div>
        <div class="info-box-subtitle"><?php echo $row->hewan_air; ?></div>
      </div>
    </div>
  </div>
  <div class="col-sm-12 col-md-6 col-lg-3 p-2">
    <div class="info-box-3 bg-white border-bottom">
      <div class="info-box-icon bg-maroon">
        <i class="gg-icon material-icons">bubble_chart</i>
      </div>
      <div class="info-box-body text-muted">
        <div class="info-box-title">Hewan Darat</div>
        <div class="info-box-subtitle"><?php echo $row->hewan_darat; ?></div>
      </div>
    </div>
  </div>
  <div class="col-sm-12 col-md-6 col-lg-3 p-2">
    <div class="info-box-3 bg-white border-bottom">
      <div class="info-box-icon bg-maroon">
        <i class="gg-icon material-icons">bubble_chart</i>
      </div>
      <div class="info-box-body text-muted">
        <div class="info-box-title">Hewan Udara</div>
        <div class="info-box-subtitle"><?php echo $row->hewan_udara; ?></div>
      </div>
    </div>
  </div>
  <div class="col-sm-12 col-md-6 col-lg-3 p-2">
    <div class="info-box-3 bg-white border-bottom">
      <div class="info-box-icon bg-maroon">
        <i class="gg-icon material-icons">bubble_chart</i>
      </div>
      <div class="info-box-body text-muted">
        <div class="info-box-title">Total Hewan</div>
        <div class="info-box-subtitle"><?php echo $row->total_hewan; ?></div>
      </div>
    </div>
  </div>
</div> <!-- end row -->
