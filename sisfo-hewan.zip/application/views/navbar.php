
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
		<div class="container">
		  <a class="navbar-brand" href="#">
		  	<div class="d-flex align-items-center">
			  	<div class="ml-2">
			  		<div style="font-weight: 600;">SISTEM INFORMASI</div>
			  		<div style="font-size: 14px;">PENGGOLONGAN JENIS HEWAN</div>
			  	</div>
		  	</div>
		  </a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNavDropdown">
		    <ul class="navbar-nav ml-auto ">
		      <li class="nav-item ">
		        <a class="nav-link" href="<?php echo base_url(); ?>">BERANDA<span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item text-uppercase">
		        <a class="nav-link" href="<?php echo base_url('hewan/air'); ?>">Hewan Air</a>
		      </li>
		      <li class="nav-item text-uppercase">
		        <a class="nav-link" href="<?php echo base_url('hewan/darat'); ?>">Hewan Darat</a>
		      </li>
		      <li class="nav-item text-uppercase">
		        <a class="nav-link" href="<?php echo base_url('hewan/udara'); ?>">Hewan Udara</a>
		      </li>
		    </ul>
		  </div>
		</div>
	</nav>
