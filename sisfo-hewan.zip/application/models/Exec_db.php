<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exec_db extends CI_Model {
	function __construct(){
		parent::__construct();
	}
	public function json($sql){
		header('content-type:application/json');
		$json = array();
		$qry = $this->db->query($sql);
		foreach ($qry->result_object() as $row){
			$json[] = $row;
		}
		return json_encode($json);
	}

	public function insert($table, $value){
		$qry = $this->db->insert($table, $value);
		return ($qry == 'true') ? "sukses_insert" : "gagal";
	}

	public function hapus($table, $value){
		$qry = $this->db->delete($table, $value);
		return ($qry == 'true') ? "sukses_delete" : "gagal";
	}
	public function perbarui($table, $id, $data){
		$this->db->where('id', $id);
		$data = $this->db->update($table, $data);
		return ($data == 'true') ? "sukses_perbarui" : "gagal" ;
	}
	public function update($table, $cond, $id, $data){
		$this->db->where($cond, $id);
		$data = $this->db->update($table, $data);
		return ($data == 'true') ? "sukses_update" : "gagal" ;
	}

	public function ss_datatables($table, $primaryKey, $columns){
		$sql_details = array(
		    'host' => $this->db->hostname,
		    'user' => $this->db->username,
		    'pass' => $this->db->password,
		    'db'   => $this->db->database
		);	
		$this->load->helper('ssp.class');
		echo json_encode( 
			SSP::simple($_GET, $sql_details, $table, $primaryKey, $columns )
		);
	}

}
