<?php 

	function ph($string){
	    $options = [
	        'cost' => 5
	    ];
		return password_hash($string, PASSWORD_DEFAULT, $options);
	}

	function repInjeksi($string){
	    $repString = str_split("!@#$%^&*()_-=+|\][[`~'\";:/?.>,<{}");
		return str_replace($repString, '', $string);
	}

	function cekChar($string){
		return (preg_match("/[^A-Za-z0-9]/", $string)) ? "not_char" : "is_char";
	}

	function numOnly($val){
		$repNumber = str_split("!@#$%^&*()_-=+|\][[`~'\";:/?.>,<{}qwertyuioplkjhgfdsazxcvbnm");
		return intval(str_replace($repNumber, '', $val));
	}

	/*merubah format angka ke format rupiah*/
	function rp($a){
		return number_format($a,0,".",".");
	}


function tglHariJam($date){
	$hari = array(1 => "Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu");
	$tgl = explode(" ", $date);
	$tgl1 = explode("-", $tgl[0]);
	$no = date('N',strtotime($date));
	return $hari[$no].", ".$tgl1[2]."/".$tgl1[1]."/".$tgl1[0]. " ". $tgl[1];
}

function tglHari($date){
	$hari = array(1 => "Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu");
	$tgl = explode(" ", $date);
	$tgl1 = explode("-", $tgl[0]);
	$no = date('N',strtotime($date));
	return $hari[$no].", ".$tgl1[2]."/".$tgl1[1]."/".$tgl1[0];
}

function tgl($date){
	$tgl = explode(" ", $date);
	$tgl1 = explode("-", $tgl[0]);
	return $tgl1[2]."/".$tgl1[1]."/".$tgl1[0];
}

function reset_tgl($tgl){
	$tgl = explode(" ", $tgl);
	return $tgl[0];
}

/*validasi image*/
function is_img($path,$type){
  switch ($type) {
    case 'gambar':
      $a = @getimagesize($path);
      $image_type = $a[2];
      if (in_array($image_type, array(IMAGETYPE_GIF,IMAGETYPE_PNG,IMAGETYPE_JPEG,IMAGETYPE_PNG,IMAGETYPE_BMP))) {
        return "true";
      }else{
        return "false";
      }
      break;
    
    default:
    echo "terjadi kesalahan";
      break;
  }
  }

function get_ar($ar){
	$arr = [];
	$arr = $ar;
	return json_encode($arr);
}


function up_file($file,$folder,$rename){
	$data = basename($_FILES[$file]["name"]);
    $format_file = pathinfo($data,PATHINFO_EXTENSION);
	$temp = $_FILES[$file]["tmp_name"];
	$location = $folder.$_FILES[$file]["name"];
	if (is_img($_FILES[$file]["tmp_name"],'gambar') ==true) {
		move_uploaded_file($temp,$location);
        $code = $rename.date("YmdHis");
	    rename($location, $folder.$code.".".$format_file);
	    $gambar_baru = $code.".".$format_file;
	    return $gambar_baru;
	}else{
		return "Maaf, file tidak didukung!";
	}
}


	function enkrip($text){
		$password="4Bu_$0Fy4N";
		return openssl_encrypt(base64_encode($text),"AES-128-ECB",$password);
	}
	function dekrip($encrypted_string){
		$password="4Bu_$0Fy4N";
		// $encrypted_string=openssl_encrypt($text,"AES-128-ECB",$password);
		return base64_decode(openssl_decrypt($encrypted_string,"AES-128-ECB",$password));
	}
	
	function url_dash($caption){
		// $aaa = str_split(",!@#$%^&*()_=+|\][[`~'\";:/?.><{} ");
		$aaa = [', ', ' ,', ', ', ' '];
		return str_replace($aaa, "-", strtolower($caption));
	}

 ?>
