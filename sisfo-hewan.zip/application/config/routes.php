<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] 					= 'welcome';
$route['admin'] 								= 'admin/view';
$route['admin/(:any)'] 							= 'admin/view/$1/$2';
// $route['(:any)']				 				= 'welcome/index/$1';
$route['hewan/(:any)']				 			= 'welcome/index/$1';
$route['kategori/(:any)']			 			= 'welcome/index/$1';
$route['read/(:num)/(:any)']				 	= 'welcome/read/$1/$2';
$route['404_override'] 							= '';
$route['translate_uri_dashes'] 					= true;
