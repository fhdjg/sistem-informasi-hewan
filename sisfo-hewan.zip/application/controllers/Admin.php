<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('exec_db');
		$this->load->library('encryption');
	}

	public function view($page = 'beranda'){
		if (!$this->session->userdata('admin_randi_id')) {
			$this->load->view('admin/login');
		}else{
	        if (!file_exists(APPPATH.'views/admin/pages/'.$page.'.php')){
                show_404();
			}else{
				$this->load->view('admin/templates/header');
				$this->load->view('admin/templates/sidebar-menu');
				$this->load->view('admin/pages/'.$page);
				$this->load->view('admin/templates/footer');
			}
		}
	}
}
