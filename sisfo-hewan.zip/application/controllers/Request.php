<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Request extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('exec_db');
		// $this->load->library('encryption');
	}

	function up_gambar($nama_file, $lokasi_file, $new_name){
        $config['upload_path']		= $lokasi_file;
        $config['allowed_types']	= 'jpg|png|jpeg|JPG|PNG';
        $config['max_size']			= 700;
		$config['file_name'] 		= $new_name.date('dmYhis');

        $this->load->library('upload', $config);
        if (!$this->upload->do_upload($nama_file)){
            $error = array('error' => $this->upload->display_errors());
            var_dump($error);
            return false;
        }else{
            $data = $this->upload->data();
            return $data['file_name'];
        }
	}
	function cu_kategori($act){
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$data['nm_kategori'] = $_POST['txt_kategori'];
			if ($act === 'insert') {
				echo $this->exec_db->insert('t_kategori', $data);
			}elseif ($act ==='update') {
				$id = @$_GET['id'];
				echo $this->exec_db->update('t_kategori', 'id', $id, $data);
			}
		}
	}
	function cu_postingan($act){
		if ($_SERVER['REQUEST_METHOD'] === 'POST'){
			$post = $this->input->post();
			$get = $this->input->get();
			$data['nm_hewan'] 		= $post['nm_hewan'];
			$data['id_tempat_hidup']= $post['tempat_hidup'];
			$data['id_kategori'] 	= $post['id_kategori'];
			$data['deskripsi']	 	= $post['deskripsi'];
			if (!empty($_FILES['gmb']['name'])) {
				$data['gmb'] 		= $this->up_gambar('gmb', 'img/hewan/', "hewan_");
			}
			if ($act === 'insert') {
				echo $this->exec_db->insert('t_hewan', $data);
			}elseif ($act === 'update') {
				$id = $_GET['id'];
				echo $this->exec_db->update('t_hewan', 'id', $id, $data);
			}
		}else{
			show_404();
		}
	}

	public function cu_gmb_slide(){
		$post = $this->input->post();
		$get = $this->input->get();
		$data["caption"]= $post['txt_caption'];
		$data["urutan"]	= $post['txt_urutan'];
		$data["status"]	= $post['txt_status'];
		if (!empty($_FILES['gmb_slide']['name'])) {
			$data['gambar'] = $this->up_gambar('gmb_slide', 'img/img_slide', "img_slide_");
		}
		if ($get['action'] === 'insert') {
			echo $this->exec_db->insert('t_gmb_slide', $data);
		}elseif ($get['action'] === 'update') {
			$id = $get['id'];
			echo $this->exec_db->update('t_gmb_slide', 'id', $id, $data);
		}
	}
	function update_show_gmb_slide($id, $status){
		$this->exec_db->update('t_gmb_slide', 'id', $id, ['status' => $status]);
	}
}
