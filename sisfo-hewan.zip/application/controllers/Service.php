<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('exec_db');
		$this->load->helper('function');
	}
	public function get_kategori($id = null){
		$data =  ["data" => json_decode($this->exec_db->json("SELECT * FROM t_kategori WHERE id LIKE '%$id%' ORDER BY nm_kategori")) ];
		echo json_encode($data);
	}
	public function get_gmb_slide($id){
		echo $this->exec_db->json("SELECT * FROM t_gmb_slide WHERE id = '$id'");
	}
	public function get_ss_hewan(){
			$id_kategori = @$this->input->get('id_kategori');
			$sql 	= "SELECT * FROM v_daftar_hewan";
			$table 	= <<<EOT
				($sql) temp
EOT;
		$primaryKey	 = 'id';
		$columns = array(
		    array( 'db' => 'id',			'dt' => 'id' ),
		    array( 'db' => 'nm_hewan',		'dt' => 'nm_hewan' ),
		    array( 'db' => 'tempat_hidup',	'dt' => 'tempat_hidup' ),
		    array( 'db' => 'nm_kategori',	'dt' => 'nm_kategori' ),
		    array( 'db' => 'deskripsi',		'dt' => 'deskripsi' ),
		    array( 'db' => 'id_provinsi',	'dt' => 'id_provinsi' ),
		    array( 'db' => 'nm_provinsi',	'dt' => 'nm_provinsi' ),
		    array( 'db' => 'gmb',			'dt' => 'gmb' )
		);
		$this->exec_db->ss_datatables($table, $primaryKey, $columns);
	}
	public function get_ss_gmb_slide(){
		$table		 = 't_gmb_slide';
		$primaryKey	 = 'id';
		$columns = array(
		    array( 'db' => 'id',		'dt' => 'id' ),
		    array( 'db' => 'caption',	'dt' => 'caption' ),
		    array( 'db' => 'gambar',	'dt' => 'gambar' ),
		    array( 'db' => 'urutan',	'dt' => 'urutan' ),
		    array( 'db' => 'status',	'dt' => 'status' )
		);
		$this->exec_db->ss_datatables($table, $primaryKey, $columns);
	}

}
