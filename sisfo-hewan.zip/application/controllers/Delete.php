<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delete extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('exec_db');
	}
	function kategori(){
		if (!empty($_POST['id'])) {
			$data['id'] = $_POST['id'];
			echo $this->exec_db->hapus('t_kategori', $data);
		}
	}
	function daftar_hewan(){
		if (!empty($_POST['id'])) {
			$data['id'] = $_POST['id'];
			$gmb 		= ($_POST['gmb'] == '' ? "nopic.jpg" : $_POST['gmb']);
			echo $this->exec_db->hapus('t_hewan', $data);
	        if (file_exists('img/hewan/'.$gmb)){
				unlink('img/hewan/'.$gmb);
			}
		}
	}
	function del_gmb_slide(){
		$gmb = $this->input->post("gmb");
		$data["id"] = $this->input->post('id');
		echo $this->exec_db->hapus('t_gmb_slide', $data);
		@unlink('img/img_slide/'.$gmb);
	}
}
