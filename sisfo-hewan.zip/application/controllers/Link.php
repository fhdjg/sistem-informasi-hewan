<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Link extends CI_Controller {

	public function logout_admin(){
		session_destroy();
		redirect("admin");
	}
}
