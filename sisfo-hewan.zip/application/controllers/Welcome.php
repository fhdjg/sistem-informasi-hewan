<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index(){
        // if (!file_exists(APPPATH.'views/admin/pages/'.$page.'.php')){
            // show_404();
		// }else{
			$this->load->view('header');
			$this->load->view('navbar');
			$this->load->view('img_slide');
			$this->load->view('pages/beranda');
			$this->load->view('footer');
		// }
	}
	public function read(){
		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('pages/read');
		$this->load->view('footer');
	}
}
