"use strict";

function hapus(label, href){
  var r = confirm("Hapus Data "+ label + " ?");
  if (r === true) {
	window.location.href= href;
  }
}

function tgl(str){
  var bulan = new Date(str).getMonth()+1;
  var tgl = str.split(' ');
  var tgl0 = tgl[0].split('-');
  return tgl0[2] +"/"+ tgl0[1] +"/"+ tgl0[0];
}

function tgl_nip(str){
  var tgl = str.split('-');
  return tgl[2] +"-"+ tgl[1] +"-"+ tgl[0];
}

function showImg(inputFile, tampilDi){
    $(inputFile).change(function(e){
    var URL = window.URL;
    var load_img = URL.createObjectURL(e.target.files[0]);
    $(tampilDi).attr('src', load_img);
  });
}