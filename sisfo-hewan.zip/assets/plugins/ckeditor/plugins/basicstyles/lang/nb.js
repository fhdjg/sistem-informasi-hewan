﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'nb', {
	bold: 'Fet',
	italic: 'Kursiv',
	strike: 'Gjennomstreking',
	subscript: 'Senket skrift',
	superscript: 'Hevet skrift',
	underline: 'Understreking'
} );
